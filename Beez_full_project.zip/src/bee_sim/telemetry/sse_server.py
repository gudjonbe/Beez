# placeholder for future SSE server
