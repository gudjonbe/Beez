# placeholder for future telemetry HTTP endpoints
