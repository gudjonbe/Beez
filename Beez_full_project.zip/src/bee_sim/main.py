from bee_sim.telemetry.ws_server import app
