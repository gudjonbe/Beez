"""Beez package — runnable WS demo aligned to your original structure."""
